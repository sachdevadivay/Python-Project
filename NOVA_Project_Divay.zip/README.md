# 🤖 NOVA – Python Assistant

Developed by **Divay**

## Features
- Calculator
- Even/Odd Checker
- Table Generator
- Joke Teller
- Password Generator
- Date & Time

## Run
python nova_exam_project.py
